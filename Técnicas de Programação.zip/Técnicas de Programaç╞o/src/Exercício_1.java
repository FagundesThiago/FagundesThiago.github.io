import java.io.File;
import java.util.Scanner;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;

public class Exerc�cio_1 {

	public static void main(String[] args) throws IOException, FileNotFoundException {
		Scanner leituraPeloTeclado = new Scanner(System.in);
		int nCase;
		System.out.println("Informe o nome de um arquivo ou diret�rio:");
		String nome = leituraPeloTeclado.nextLine();
		File objetoArquivo = new File(nome);
		if (objetoArquivo.exists()) {
			System.out.printf("\nArquivo (%s) j� existe - tamanho: %d bytes\n", objetoArquivo.getName(),
					objetoArquivo.length());
			System.out
					.println("O que deseja fazer? \nDigite 0 para 'Listar conte�do' \nDigite 1 para 'Incluir produto'");
			nCase = leituraPeloTeclado.nextInt();
			switch (nCase) {
			case 0:
				LeituraArquivos(nome);
				break;
			case 1:
				InclusaoProduto(nome);
				break;
			}
		} else {
			objetoArquivo.createNewFile();
			System.out.println("Deseja incluir produtos nesse arquivo? \nDigite 1 para 'Sim' \nDigite 0 para 'N�o'");
			nCase = leituraPeloTeclado.nextInt();
			if (nCase == 1) {
				InclusaoProduto(nome);
			}
		}
		do {
			System.out.println(
					"\nDeseja realizar mais alguma a��o? \nDigite 0 para 'N�o' \nDigite 1 para 'Listar conte�do' \nDigite 2 para 'Incluir produto'");
			nCase = leituraPeloTeclado.nextInt();
			if (nCase == 1) {
				LeituraArquivos(nome);
			} else {
				if (nCase == 2) {
					InclusaoProduto(nome);
				}
			}
		} while (nCase != 0);
	}

	static public void LeituraArquivos(String nome) throws IOException {

		FileInputStream arquivoDeEntrada = new FileInputStream("C:\\Users\\Robson\\Desktop\\Thiago\\" + nome);
		DataInputStream fluxoDeEntrada = new DataInputStream(arquivoDeEntrada);
		int verificacao = 1;
		while (verificacao != 0) {
			String nomeProduto = fluxoDeEntrada.readUTF();
			int quantidade = fluxoDeEntrada.readInt();
			int tamanhoNome = fluxoDeEntrada.readInt();
			float preco = fluxoDeEntrada.readFloat();
			System.out.printf("\nNome..................: %s\n", nomeProduto);
			System.out.printf("Quantidade............: %d\n", quantidade);
			System.out.printf("Tamanho do Nome.......: %d\n", tamanhoNome);
			System.out.printf("Pre�o.................: R$ %.2f\n", preco);
			verificacao = fluxoDeEntrada.available();
		}
		arquivoDeEntrada.close();
	}

	static public void InclusaoProduto(String nome) throws IOException, FileNotFoundException {

		Scanner leituraPeloTeclado = new Scanner(System.in);
		FileOutputStream arquivoDeSaida = new FileOutputStream("C:\\Users\\Robson\\Desktop\\Thiago\\" + nome, true);
		DataOutputStream fluxoDeSaida = new DataOutputStream(arquivoDeSaida);
		System.out.println("Informe o nome do produto:");
		String nomeProduto = leituraPeloTeclado.nextLine();
		System.out.println("Informe a quantidade do produto:");
		int quantidade = leituraPeloTeclado.nextInt();
		System.out.println("Informe o pre�o do produto:");
		float preco = leituraPeloTeclado.nextFloat();
		int tamanhoNome = nomeProduto.length();
		fluxoDeSaida.writeUTF(nomeProduto);
		fluxoDeSaida.writeInt(quantidade);
		fluxoDeSaida.writeInt(tamanhoNome);
		fluxoDeSaida.writeFloat(preco);
		fluxoDeSaida.flush();
		arquivoDeSaida.close();
	}
}
